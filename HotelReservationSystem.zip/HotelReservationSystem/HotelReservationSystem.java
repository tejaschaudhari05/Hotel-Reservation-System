package HotelReservationSystem;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;


public class HotelReservationSystem {
    private static final String BOOKINGS_FILE = "bookings.csv";
    private static final DateTimeFormatter DF = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private Map<Integer, Room> rooms = new HashMap<>();
    private Map<String, Booking> bookings = new HashMap<>(); 
    private Scanner sc = new Scanner(System.in);
    private Random random = new Random();

    public static void main(String[] args) {
        HotelReservationSystem app = new HotelReservationSystem();
        app.bootstrapRooms();
        app.loadBookings();
        app.runMenu();
    }

  
    private void bootstrapRooms() {
      
        int id = 1;
        for (int i = 0; i < 8; i++) rooms.put(id, new Room(id++, "Standard", 3000));
        for (int i = 0; i < 6; i++) rooms.put(id, new Room(id++, "Deluxe", 5000));
        for (int i = 0; i < 3; i++) rooms.put(id, new Room(id++, "Suite", 9000));
    }

    private void runMenu() {
        while (true) {
            System.out.println("\n--- Hotel Reservation System ---");
            System.out.println("1. Search rooms");
            System.out.println("2. Make reservation");
            System.out.println("3. Cancel reservation");
            System.out.println("4. View all bookings");
            System.out.println("5. View bookings by customer");
            System.out.println("6. Show room inventory");
            System.out.println("0. Exit");
            System.out.print("Choose: ");
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1": handleSearch(); break;
                    case "2": handleBook(); break;
                    case "3": handleCancel(); break;
                    case "4": handleViewAll(); break;
                    case "5": handleViewByCustomer(); break;
                    case "6": showRoomInventory(); break;
                    case "0": saveBookings(); System.out.println("Goodbye!"); return;
                    default: System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void handleSearch() {
        LocalDate from = readDate("Enter check-in date (yyyy-MM-dd): ");
        LocalDate to = readDate("Enter check-out date (yyyy-MM-dd): ");
        if (!validateRange(from, to)) return;
        System.out.print("Room type (Standard/Deluxe/Suite or ALL): ");
        String type = sc.nextLine().trim();
        List<Room> avail = searchAvailableRooms(from, to.minusDays(1), type.equalsIgnoreCase("ALL") ? null : type);
        if (avail.isEmpty()) {
            System.out.println("No rooms available for given dates and type.");
        } else {
            System.out.println("Available rooms:");
            for (Room r : avail) {
                System.out.printf("RoomId: %d | Type: %s | Price/night: %.0f%n", r.id, r.type, r.pricePerNight);
            }
        }
    }

    private void handleBook() {
        System.out.print("Customer name: ");
        String name = sc.nextLine().trim();
        System.out.print("Customer phone: ");
        String phone = sc.nextLine().trim();
        LocalDate from = readDate("Enter check-in date (yyyy-MM-dd): ");
        LocalDate to = readDate("Enter check-out date (yyyy-MM-dd): ");
        if (!validateRange(from, to)) return;
        System.out.print("Preferred room type (Standard/Deluxe/Suite or ALL): ");
        String type = sc.nextLine().trim();
        List<Room> avail = searchAvailableRooms(from, to.minusDays(1), type.equalsIgnoreCase("ALL") ? null : type);
        if (avail.isEmpty()) {
            System.out.println("No available rooms for these dates and type.");
            return;
        }
        System.out.println("Choose a room by ID from the available list:");
        for (Room r : avail) System.out.printf("RoomId: %d | %s | %.0f per night%n", r.id, r.type, r.pricePerNight);
        int chosenId = readInt("Room ID: ");
        Room chosen = rooms.get(chosenId);
        if (chosen == null || !avail.contains(chosen)) {
            System.out.println("Invalid room choice or room not available.");
            return;
        }
        long nights = to.toEpochDay() - from.toEpochDay();
        double total = nights * chosen.pricePerNight;
        System.out.printf("Booking %d nights. Total = %.0f INR%n", nights, total);

  
        if (!simulatePayment(total)) {
            System.out.println("Payment failed. Booking cancelled.");
            return;
        }

        String bookingId = generateBookingId();
        Booking b = new Booking(bookingId, chosen.id, chosen.type, name, phone, from, to, total);
        bookings.put(bookingId, b);
        saveBookings();
        System.out.println("Booking successful! Your Booking ID: " + bookingId);
    }

    private void handleCancel() {
        System.out.print("Enter Booking ID to cancel: ");
        String id = sc.nextLine().trim();
        Booking b = bookings.get(id);
        if (b == null) {
            System.out.println("Booking ID not found.");
            return;
        }
        bookings.remove(id);
        saveBookings();
        System.out.println("Booking " + id + " cancelled.");
    }

    private void handleViewAll() {
        if (bookings.isEmpty()) {
            System.out.println("No bookings.");
            return;
        }
        bookings.values().stream()
                .sorted(Comparator.comparing(Booking::getFromDate))
                .forEach(System.out::println);
    }

    private void handleViewByCustomer(){
        System.out.print("Enter customer name (or phone): ");
        String q = sc.nextLine().trim().toLowerCase();
        List<Booking> list = new ArrayList<>();
        for (Booking b : bookings.values()) {
            if (b.customerName.toLowerCase().contains(q) || b.customerPhone.toLowerCase().contains(q)) list.add(b);
        }
        if (list.isEmpty()) System.out.println("No bookings found for that customer.");
        else list.forEach(System.out::println);
    }

    private void showRoomInventory() {
        Map<String, Long> counts = new HashMap<>();
        rooms.values().forEach(r -> counts.put(r.type, counts.getOrDefault(r.type, 0L)+1));
        System.out.println("Room inventory:");
        counts.forEach((k,v) -> System.out.printf("%s : %d rooms%n", k, v));
    }

    
    private List<Room> searchAvailableRooms(LocalDate from, LocalDate to, String typeFilter) {
        List<Room> result = new ArrayList<>();
        outer:
        for (Room r : rooms.values()) {
            if (typeFilter != null && !r.type.equalsIgnoreCase(typeFilter)) continue;
            for (Booking b : bookings.values()) {
                if (b.roomId == r.id) {
                    
                    LocalDate bStart = b.fromDate;
                    LocalDate bEndExclusive = b.toDate; 
                    LocalDate bEnd = bEndExclusive.minusDays(1);
                    if (rangesOverlap(from, to, bStart, bEnd)) {
                        continue outer; 
                    }
                }
            }
            result.add(r);
        }
        result.sort(Comparator.comparingDouble(r -> r.pricePerNight));
        return result;
    }

    private boolean rangesOverlap(LocalDate a1, LocalDate a2, LocalDate b1, LocalDate b2) {
        return !(a2.isBefore(b1) || a1.isAfter(b2));
    }

    private boolean validateRange(LocalDate from, LocalDate to) {
        if (from == null || to == null) {
            System.out.println("Invalid dates.");
            return false;
        }
        if (!to.isAfter(from)) {
            System.out.println("Check-out date must be after check-in.");
            return false;
        }
        if (from.isBefore(LocalDate.now())) {
            System.out.println("Check-in date cannot be in the past.");
            return false;
        }
        return true;
    }

    
    private boolean simulatePayment(double amount) {
        System.out.println("---- Payment Simulation ----");
        System.out.println("Amount to pay: " + (long)amount + " INR");
        System.out.print("Enter card number (16 digits simulated): ");
        String card = sc.nextLine().trim();
        if (card.length() != 16 || !card.matches("\\d{16}")) {
            System.out.println("Invalid card number format.");
            return false;
        }
        System.out.print("Enter expiry (MM/yy): ");
        String expiry = sc.nextLine().trim();
        System.out.print("Enter CVV (3 digits): ");
        String cvv = sc.nextLine().trim();
        if (!cvv.matches("\\d{3}")) {
            System.out.println("Invalid CVV.");
            return false;
        }

        boolean success = random.nextDouble() > 0.05;
        if (success) System.out.println("Payment successful (simulated).");
        else System.out.println("Payment declined (simulated).");
        return success;
    }

   
    private void saveBookings() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(BOOKINGS_FILE))) {
           
            pw.println("bookingId,roomId,roomType,customerName,customerPhone,fromDate,toDate,total");
            for (Booking b : bookings.values()) pw.println(b.toCsv());
        } catch (IOException e) {
            System.out.println("Failed to save bookings: " + e.getMessage());
        }
    }

    private void loadBookings() {
        File f = new File(BOOKINGS_FILE);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line = br.readLine(); 
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                Booking b = Booking.fromCsv(line);
                if (b != null) bookings.put(b.bookingId, b);
            }
        } catch (IOException e) {
            System.out.println("Failed to load bookings: " + e.getMessage());
        }
    }

    
    private LocalDate readDate(String prompt) {
        System.out.print(prompt);
        String s = sc.nextLine().trim();
        try {
            return LocalDate.parse(s, DF);
        } catch (Exception e) {
            System.out.println("Invalid date. Use yyyy-MM-dd.");
            return null;
        }
    }

    private int readInt(String prompt) {
        System.out.print(prompt);
        String s = sc.nextLine().trim();
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) { return -1; }
    }

    private String generateBookingId() {
        return "BKG-" + (100000 + random.nextInt(900000));
    }

   
    static class Room {
        int id;
        String type;
        double pricePerNight;
        Room(int id, String type, double pricePerNight) {
            this.id = id; this.type = type; this.pricePerNight = pricePerNight;
        }
        public String toString() { return id + ":" + type + ":" + pricePerNight; }
    }

    static class Booking {
        String bookingId;
        int roomId;
        String roomType;
        String customerName;
        String customerPhone;
        LocalDate fromDate;
        LocalDate toDate; 
        double total;

        Booking(String bookingId, int roomId, String roomType, String customerName, String customerPhone,
                LocalDate fromDate, LocalDate toDate, double total) {
            this.bookingId = bookingId;
            this.roomId = roomId;
            this.roomType = roomType;
            this.customerName = customerName;
            this.customerPhone = customerPhone;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.total = total;
        }

        static Booking fromCsv(String csv) {
        
            String[] parts = splitCsv(csv);
            try {
                String bid = parts[0];
                int rid = Integer.parseInt(parts[1]);
                String rtype = parts[2];
                String name = parts[3];
                String phone = parts[4];
                LocalDate f = LocalDate.parse(parts[5], DF);
                LocalDate t = LocalDate.parse(parts[6], DF);
                double total = Double.parseDouble(parts[7]);
                return new Booking(bid, rid, rtype, name, phone, f, t, total);
            } catch (Exception e) {
                System.out.println("Malformed booking line: " + csv);
                return null;
            }
        }

        String toCsv() {
           
            return String.join(",",
                    escape(bookingId),
                    String.valueOf(roomId),
                    escape(roomType),
                    escape(customerName),
                    escape(customerPhone),
                    fromDate.format(DF),
                    toDate.format(DF),
                    String.valueOf((long)total)
            );
        }

        private static String escape(String s) {
            if (s.contains(",") || s.contains("\"")) {
                s = s.replace("\"", "\"\"");
                return "\"" + s + "\"";
            } else return s;
        }

        private static String[] splitCsv(String line) {
           
            List<String> parts = new ArrayList<>();
            StringBuilder cur = new StringBuilder();
            boolean inQuotes = false;
            for (int i = 0; i < line.length(); i++) {
                char c = line.charAt(i);
                if (c == '"') {
                    inQuotes = !inQuotes;
                 
                    if (inQuotes && i+1 < line.length() && line.charAt(i+1) == '"') {
                        cur.append('"'); i++;
                    }
                } else if (c == ',' && !inQuotes) {
                    parts.add(cur.toString());
                    cur.setLength(0);
                } else cur.append(c);
            }
            parts.add(cur.toString());
            return parts.toArray(new String[0]);
        }

        public LocalDate getFromDate() { return fromDate; }

        public String toString() {
            return String.format("ID:%s | Room:%d(%s) | %s to %s | Customer:%s (%s) | Total: %.0f",
                    bookingId, roomId, roomType, fromDate.format(DF), toDate.format(DF), customerName, customerPhone, total);
        }
    }
}
